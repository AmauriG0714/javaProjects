//Name: Amauri Gay
//Description: hangman game 

import java.util.Scanner;
import java.util.Random;
  
public class Hangman {
 
    static int wins = 0;
    static int losses = 0;
    static int rounds = 0;
 
    private static void lose() {
        losses++;
 
    }
 
    private static void win() {
        wins++;
 
    }
 
    private static void round() {
        rounds++;
    }
 
    public static void main(String[] args) {
        int UsrIn;
        
        Scanner first_name = new Scanner( System.in );
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Please enter name: ");
        String name = first_name.nextLine();
        
        
        Random random = new Random();
        String[] WordList = {"watch","pizza", "deathstar","jedi","heckle",
        "random","ligma","tugma","sugma","tipis","tiptis","death","fuckyou" };
      
        boolean playing = true;
        while (playing) {
           
            System.out.println("Welcome to Hangman!");
             int x = 0;
            char[] randomGuessWord =
                WordList[random.nextInt(WordList.length)].toCharArray();
            int amountOfGuesses = randomGuessWord.length;
            int GuessTries = 6;
            char[] playerGuess = new char[amountOfGuesses];

            for (int i = 0; i < playerGuess.length; i++) {
                playerGuess[i] = '_';
            }
 
            boolean wordIsGuessed = false;
            int tries = 0;
                    //determines if you've done all your tries or wordguess
            while (!wordIsGuessed && tries != GuessTries) {
                   boolean letter = false;
                System.out.println("Current guesses: ");
                printArray(playerGuess);
                System.out.printf(
                    "You have %d tries left. \n",  GuessTries - tries);
                System.out.println("Enter a single character");
                char input = scanner.nextLine().charAt(0);
                tries++;
 
                if (input == '-') {
                    playing = false;
                    wordIsGuessed = true;
                } else {
                    for (int i = 0; i < randomGuessWord.length; i++) {
                        if (randomGuessWord[i] == input) {
                            playerGuess[i] = input;
                            letter = true;
                            x++; 
                            //if letter is correct it cancels out the tries++
                            tries--;
                        }
                    }
 
                    if (isTheWordGuessed(playerGuess)) {
                        wordIsGuessed = true;
                        System.out.println("Congratulations you won!");
                        win();
                        rounds++;
                    }
                     else if(!letter) { 
                        x++;
                        displayHangman(x);
                    }
                }
 
            }
            if (GuessTries == 0)
                System.out.println("You ran out of guesses");
            lose();
            rounds++;
            System.out.println("Do you want to play again? (yes/no)");
            String anotherGame = scanner.nextLine();
 
            if (anotherGame.equals("no")) {
                System.out.println("You chose to end");
                playing = false;
            }
           else if (anotherGame.equals("yes"))
           {
                System.out.println("FECK YOU");
                
                playing = true;
            }
 
        }
 
        System.out.println("Game over..");
        System.out.println("wins: " + wins + " losses: "
            + losses + " rounds: " + rounds);
    }
 
    public static void printArray(char[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i] + " ");
        }
        System.out.println();
    }
     
      public static boolean isTheWordGuessed(char[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == '_')
                return false;
        }
        return true;
     }
         //display hangman methods
        public static void displayHangman(int x) {
        //hangman body parts
        String one = "  0 ";
        String two1 = " | ";
        String two2 = " /| ";
        String two3 = " /|\\";
        String three1 = " /";
        String three2 = " / \\";
        
        //outputs wrong
        System.out.println("Wrong");
        
        //displays head
        if(x >= 1) {
            System.out.println(one);
        }
        
        //displays midsection
        if(x == 2) {
            System.out.println(two1);
        }
        else if(x == 3) {
            System.out.println(two2);
        }        
        else if(x >= 4) {
            System.out.println(two3);
        }
        
        //displays legs
        if (x == 5) {
            System.out.println(three1);
        }
        else if (x == 6) {
            System.out.println(three2);
        }
     } 
    }

